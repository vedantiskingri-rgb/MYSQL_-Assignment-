-- SALES MANAGEMENT SYSTEM SCHEMA

-- 1. Create the database
CREATE DATABASE IF NOT EXISTS sales_management_db;

-- 2. Use the created database
USE sales_management_db;

-- 3. Create 'products' table
CREATE TABLE IF NOT EXISTS products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(100) NOT NULL UNIQUE,
    category VARCHAR(50),
    price DECIMAL(10, 2) NOT NULL CHECK (price > 0),
    stock_quantity INT NOT NULL CHECK (stock_quantity >= 0),
    added_date DATE DEFAULT (CURRENT_DATE)
);

-- 4. Insert data into 'products' table (25 records)
INSERT INTO products (product_name, category, price, stock_quantity, added_date) VALUES
('Laptop Pro X', 'Electronics', 120000.00, 50, '2024-01-10'),
('Smartphone Ultra', 'Electronics', 85000.00, 120, '2024-01-15'),
('Wireless Earbuds 2.0', 'Audio', 15000.00, 300, '2024-01-20'),
('Smart Watch Series 7', 'Wearables', 22000.00, 80, '2024-02-01'),
('4K LED TV 55inch', 'Electronics', 65000.00, 30, '2024-02-10'),
('Bluetooth Speaker Mini', 'Audio', 4500.00, 250, '2024-02-15'),
('External SSD 1TB', 'Storage', 10000.00, 100, '2024-03-01'),
('Gaming Keyboard RGB', 'Peripherals', 6000.00, 75, '2024-03-05'),
('Webcam HD 1080p', 'Peripherals', 3000.00, 150, '2024-03-10'),
('Office Desk Chair', 'Furniture', 18000.00, 40, '2024-04-01'),
('Ergonomic Mouse', 'Peripherals', 1200.00, 200, '2024-04-05'),
('Graphics Tablet', 'Electronics', 25000.00, 20, '2024-04-10'),
('Portable Power Bank 20000mAh', 'Accessories', 3500.00, 180, '2024-05-01'),
('USB-C Hub', 'Accessories', 1800.00, 220, '2024-05-05'),
('Noise Cancelling Headphones', 'Audio', 28000.00, 60, '2024-05-10'),
('Action Camera 4K', 'Electronics', 35000.00, 25, '2024-06-01'),
('Fitness Tracker Pro', 'Wearables', 8000.00, 90, '2024-06-05'),
('Smart Home Hub', 'Smart Home', 12000.00, 35, '2024-06-10'),
('Robot Vacuum Cleaner', 'Home Appliances', 20000.00, 15, '2024-07-01'),
('Digital Camera Mirrorless', 'Electronics', 90000.00, 10, '2024-07-05'),
('E-Reader Kindle', 'Books & Media', 10000.00, 50, '2024-07-10'),
('Gaming Console X', 'Gaming', 45000.00, 20, '2024-08-01'),
('VR Headset', 'Gaming', 30000.00, 15, '2024-08-05'),
('External Hard Drive 2TB', 'Storage', 7000.00, 80, '2024-08-10'),
('Portable Projector', 'Electronics', 40000.00, 10, '2024-09-01');


-- 5. Create 'customers' table
CREATE TABLE IF NOT EXISTS customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50),
    email VARCHAR(100) UNIQUE NOT NULL,
    phone_number VARCHAR(15),
    address VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(100),
    zip_code VARCHAR(10),
    registration_date DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 6. Insert data into 'customers' table (15 records, Indian names/cities)
INSERT INTO customers (first_name, last_name, email, phone_number, address, city, state, zip_code) VALUES
('Rahul', 'Sharma', 'rahul.sharma@email.com', '9812345678', '123 MG Road', 'Bengaluru', 'Karnataka', '560001'),
('Priya', 'Singh', 'priya.singh@email.com', '9823456789', '45 Nehru Place', 'Delhi', 'Delhi', '110019'),
('Amit', 'Patel', 'amit.patel@email.com', '9834567890', '78 Linking Road', 'Mumbai', 'Maharashtra', '400050'),
('Neha', 'Gupta', 'neha.gupta@email.com', '9845678901', '10 Sector 18', 'Gurgaon', 'Haryana', '122008'),
('Suresh', 'Kumar', 'suresh.kumar@email.com', '9856789012', '22 Park Street', 'Kolkata', 'West Bengal', '700016'),
('Deepa', 'Reddy', 'deepa.reddy@email.com', '9867890123', '33 Banjara Hills', 'Hyderabad', 'Telangana', '500034'),
('Vijay', 'Malhotra', 'vijay.malhotra@email.com', '9878901234', '5 Lake Road', 'Chennai', 'Tamil Nadu', '600034'),
('Kavita', 'Jain', 'kavita.jain@email.com', '9889012345', '8 Model Town', 'Chandigarh', 'Punjab', '160017'),
('Rajat', 'Verma', 'rajat.verma@email.com', '9890123456', '15 ABC Colony', 'Pune', 'Maharashtra', '411001'),
('Anjali', 'Dubey', 'anjali.dubey@email.com', '9901234567', '67 High Street', 'Ahmedabad', 'Gujarat', '380009'),
('Manish', 'Chauhan', 'manish.c@email.com', '9912345678', '9 XYZ Apartment', 'Jaipur', 'Rajasthan', '302001'),
('Sakshi', 'Agarwal', 'sakshi.a@email.com', '9923456789', '4 Civil Lines', 'Lucknow', 'Uttar Pradesh', '226001'),
('Rohit', 'Sinha', 'rohit.s@email.com', '9934567890', '11 Brigade Road', 'Bengaluru', 'Karnataka', '560025'),
('Gauri', 'Desai', 'gauri.d@email.com', '9945678901', '2 Rajpath', 'Delhi', 'Delhi', '110001'),
('Arjun', 'Mehta', 'arjun.m@email.com', '9956789012', '7 Bandra West', 'Mumbai', 'Maharashtra', '400050');

-- 7. Create 'orders' table
CREATE TABLE IF NOT EXISTS orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL,
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_amount DECIMAL(10, 2) NOT NULL CHECK (total_amount >= 0),
    order_status ENUM('Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled') DEFAULT 'Pending',
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
);

-- 8. Insert data into 'orders' table (30 records)
INSERT INTO orders (customer_id, order_date, total_amount, order_status) VALUES
(1, '2024-10-01 10:00:00', 120000.00, 'Delivered'), -- Laptop Pro X
(2, '2024-10-01 11:30:00', 15000.00, 'Shipped'),    -- Wireless Earbuds
(3, '2024-10-02 09:15:00', 85000.00, 'Delivered'),  -- Smartphone Ultra
(4, '2024-10-02 14:00:00', 22000.00, 'Processing'), -- Smart Watch
(5, '2024-10-03 10:45:00', 65000.00, 'Pending'),    -- 4K LED TV
(6, '2024-10-03 16:00:00', 4500.00, 'Delivered'),   -- Bluetooth Speaker
(7, '2024-10-04 11:00:00', 10000.00, 'Shipped'),    -- External SSD
(8, '2024-10-04 15:30:00', 6000.00, 'Delivered'),   -- Gaming Keyboard
(9, '2024-10-05 09:00:00', 3000.00, 'Pending'),     -- Webcam HD
(10, '2024-10-05 13:00:00', 18000.00, 'Processing'),-- Office Desk Chair
(1, '2024-10-06 10:00:00', 1200.00, 'Delivered'),   -- Ergonomic Mouse
(2, '2024-10-06 14:00:00', 25000.00, 'Shipped'),    -- Graphics Tablet
(3, '2024-10-07 10:30:00', 3500.00, 'Delivered'),   -- Portable Power Bank
(4, '2024-10-07 16:00:00', 1800.00, 'Pending'),     -- USB-C Hub
(5, '2024-10-08 09:45:00', 28000.00, 'Processing'), -- Noise Cancelling Headphones
(6, '2024-10-08 14:15:00', 35000.00, 'Delivered'),  -- Action Camera
(7, '2024-10-09 10:00:00', 8000.00, 'Shipped'),     -- Fitness Tracker Pro
(8, '2024-10-09 15:00:00', 12000.00, 'Delivered'),  -- Smart Home Hub
(9, '2024-10-10 09:30:00', 20000.00, 'Pending'),    -- Robot Vacuum Cleaner
(10, '2024-10-10 13:45:00', 90000.00, 'Processing'),-- Digital Camera
(11, '2024-10-11 10:00:00', 10000.00, 'Delivered'), -- E-Reader Kindle
(12, '2024-10-11 14:00:00', 45000.00, 'Shipped'),   -- Gaming Console X
(13, '2024-10-12 10:30:00', 30000.00, 'Delivered'), -- VR Headset
(14, '2024-10-12 16:00:00', 7000.00, 'Pending'),    -- External Hard Drive
(15, '2024-10-13 09:45:00', 40000.00, 'Processing'),-- Portable Projector
(1, '2024-10-13 15:00:00', 85000.00, 'Delivered'),  -- Smartphone Ultra (repeat customer)
(2, '2024-10-14 10:00:00', 120000.00, 'Shipped'),   -- Laptop Pro X (repeat customer)
(3, '2024-10-14 14:30:00', 15000.00, 'Delivered'),  -- Wireless Earbuds (repeat customer)
(4, '2024-10-15 11:00:00', 6000.00, 'Pending'),     -- Gaming Keyboard (repeat customer)
(5, '2024-10-15 16:00:00', 22000.00, 'Processing'); -- Smart Watch (repeat customer)


-- 9. Create 'order_items' table
CREATE TABLE IF NOT EXISTS order_items (
    order_item_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10, 2) NOT NULL CHECK (unit_price > 0),
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
);

-- 10. Insert data into 'order_items' table (approx 35 records, reflecting orders)
INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
(1, 1, 1, 120000.00), -- Laptop Pro X
(2, 3, 1, 15000.00),  -- Wireless Earbuds 2.0
(3, 2, 1, 85000.00),  -- Smartphone Ultra
(4, 4, 1, 22000.00),  -- Smart Watch Series 7
(5, 5, 1, 65000.00),  -- 4K LED TV 55inch
(6, 6, 1, 4500.00),   -- Bluetooth Speaker Mini
(7, 7, 1, 10000.00),  -- External SSD 1TB
(8, 8, 1, 6000.00),   -- Gaming Keyboard RGB
(9, 9, 1, 3000.00),   -- Webcam HD 1080p
(10, 10, 1, 18000.00),-- Office Desk Chair
(11, 11, 1, 1200.00), -- Ergonomic Mouse
(12, 12, 1, 25000.00),-- Graphics Tablet
(13, 13, 2, 3500.00), -- Portable Power Bank (2 units)
(14, 14, 1, 1800.00), -- USB-C Hub
(15, 15, 1, 28000.00),-- Noise Cancelling Headphones
(16, 16, 1, 35000.00),-- Action Camera 4K
(17, 17, 1, 8000.00), -- Fitness Tracker Pro
(18, 18, 1, 12000.00),-- Smart Home Hub
(19, 19, 1, 20000.00),-- Robot Vacuum Cleaner
(20, 20, 1, 90000.00),-- Digital Camera Mirrorless
(21, 21, 1, 10000.00),-- E-Reader Kindle
(22, 22, 1, 45000.00),-- Gaming Console X
(23, 23, 1, 30000.00),-- VR Headset
(24, 24, 1, 7000.00), -- External Hard Drive 2TB
(25, 25, 1, 40000.00),-- Portable Projector
(26, 2, 1, 85000.00),  -- Smartphone Ultra (repeat)
(27, 1, 1, 120000.00), -- Laptop Pro X (repeat)
(28, 3, 1, 15000.00),  -- Wireless Earbuds (repeat)
(29, 8, 1, 6000.00),   -- Gaming Keyboard (repeat)
(30, 4, 1, 22000.00),  -- Smart Watch (repeat)
-- More complex orders with multiple items
(1, 13, 1, 3500.00), -- Power bank with Laptop
(3, 11, 1, 1200.00), -- Ergonomic mouse with Smartphone
(5, 1, 1, 120000.00), -- Laptop with TV
(10, 1, 1, 120000.00), -- Laptop with Chair
(15, 3, 1, 15000.00); -- Earbuds with Headphones