use sales_management_db;

select* from customers;
select* from products;
select* from orders;
select* from order_items;
select* from customers;
select* from customers Where City='Delhi';