Create Database SQLJOINS_db;
Use SQLJOINS_db;


CREATE TABLE students (
    student_id INT PRIMARY KEY,
    student_name VARCHAR(50),
    city VARCHAR(50)
);
INSERT INTO students (student_id, student_name, city) VALUES
(101, 'Aarav Sharma', 'Pune'),
(102, 'Diya Singh', 'Mumbai'),
(103, 'Rohan Gupta', 'Delhi'),
(104, 'Rhea Kumar', 'Bengaluru'),
(105, 'Arjun Reddy', 'Chennai'),
(106, 'Priya Verma', 'Pune');

CREATE TABLE courses (
    enrollment_id INT PRIMARY KEY,
    student_id INT, -- This is our foreign key to the students table
    course_name VARCHAR(100),
    instructor VARCHAR(50)
);

INSERT INTO courses (enrollment_id, student_id, course_name, instructor) VALUES
(1, 101, 'Data Science', 'Dr. Anand Kumar'),
(2, 102, 'Web Development (MERN)', 'Ms. Pooja Shah'),
(3, 101, 'Python for AI', 'Dr. Anand Kumar'),
(4, 103, 'Cyber Security', 'Mr. Vikram Singh'),
(5, 104, 'Cloud Computing (AWS)', 'Ms. Tanya Sharma'),
(6, 107, 'Mobile App Dev (Flutter)', 'Mr. Rahul Gupta'), -- Student 107 doesn't exist in students table
(7, NULL, 'DevOps Fundamentals', 'Mr. Ajay Mehra');     -- No student assigned to this course

