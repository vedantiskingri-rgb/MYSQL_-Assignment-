-- Create the database
CREATE DATABASE IF NOT EXISTS university_management_db;

-- Use the database
USE university_management_db;

-- 1. Students Table
-- Stores details about individual students
CREATE TABLE IF NOT EXISTS Students (
    StudentID INT PRIMARY KEY AUTO_INCREMENT,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    DateOfBirth DATE,
    Gender ENUM('Male', 'Female', 'Other'),
    Email VARCHAR(100) UNIQUE NOT NULL,
    PhoneNumber VARCHAR(15),
    Address VARCHAR(255),
    City VARCHAR(50),
    State VARCHAR(50),
    Pincode VARCHAR(10),
    EnrollmentDate DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. Courses Table
-- Stores details about the academic courses offered
CREATE TABLE IF NOT EXISTS Courses (
    CourseID INT PRIMARY KEY AUTO_INCREMENT,
    CourseName VARCHAR(100) UNIQUE NOT NULL,
    CourseCode VARCHAR(10) UNIQUE NOT NULL, -- e.g., 'CS101', 'MA201'
    Credits INT NOT NULL,
    Department VARCHAR(50) NOT NULL
);

-- 3. Marks Table (Junction Table for Many-to-Many Relationship)
-- Stores the marks obtained by a student in a specific course
CREATE TABLE IF NOT EXISTS Marks (
    MarkID INT PRIMARY KEY AUTO_INCREMENT,
    StudentID INT NOT NULL,
    CourseID INT NOT NULL,
    MarksObtained DECIMAL(5, 2) NOT NULL, -- e.g., 85.50
    Grade CHAR(2),                         -- e.g., 'A+', 'B'
    ExamDate DATE,
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID) ON DELETE CASCADE ON UPDATE CASCADE,
    UNIQUE (StudentID, CourseID) -- Ensures a student only has one mark per course
);








-- Use the database
USE university_management_db;

-- 1. Insert 30 Records into Students Table
INSERT INTO Students (FirstName, LastName, DateOfBirth, Gender, Email, PhoneNumber, Address, City, State, Pincode) VALUES
('Rohan', 'Sharma', '2003-01-10', 'Male', 'rohan.sharma@email.com', '9876543210', '12, Gandhi Nagar', 'Delhi', 'Delhi', '110001'),
('Priya', 'Singh', '2002-05-22', 'Female', 'priya.s@email.com', '9876543211', 'Flat 5A, Cyber Towers', 'Bengaluru', 'Karnataka', '560001'),
('Amit', 'Kumar', '2003-09-03', 'Male', 'amit.k@email.com', '9876543212', 'B-10, Green Park', 'Mumbai', 'Maharashtra', '400001'),
('Sneha', 'Gupta', '2004-02-14', 'Female', 'sneha.g@email.com', '9876543213', '45, Palm Street', 'Chennai', 'Tamil Nadu', '600001'),
('Vivek', 'Patel', '2002-11-28', 'Male', 'vivek.p@email.com', '9876543214', '7, Lake View Residency', 'Ahmedabad', 'Gujarat', '380001'),
('Anjali', 'Dubey', '2003-07-07', 'Female', 'anjali.d@email.com', '9876543215', 'Block C-3, Royal Apt', 'Pune', 'Maharashtra', '411001'),
('Sachin', 'Yadav', '2001-04-19', 'Male', 'sachin.y@email.com', '9876543216', '22, Surya Enclave', 'Hyderabad', 'Telangana', '500001'),
('Divya', 'Reddy', '2004-08-01', 'Female', 'divya.r@email.com', '9876543217', 'Plot 15, Vaishali Nagar', 'Jaipur', 'Rajasthan', '302001'),
('Rahul', 'Mehta', '2003-03-11', 'Male', 'rahul.m@email.com', '9876543218', 'Shop No 3, Market Rd', 'Kolkata', 'West Bengal', '700001'),
('Neha', 'Sharma', '2002-10-05', 'Female', 'neha.sh@email.com', '9876543219', '10, New Colony', 'Chandigarh', 'Punjab', '160001'),
('Arjun', 'Verma', '2004-01-25', 'Male', 'arjun.v@email.com', '9876543220', '18, Sector 10', 'Lucknow', 'Uttar Pradesh', '226001'),
('Kavya', 'Nair', '2003-06-30', 'Female', 'kavya.n@email.com', '9876543221', 'A-7, Sunshine Apts', 'Kochi', 'Kerala', '682001'),
('Gaurav', 'Jain', '2001-11-17', 'Male', 'gaurav.j@email.com', '9876543222', '33, Shivaji Marg', 'Indore', 'Madhya Pradesh', '452001'),
('Shruti', 'Pawar', '2004-04-02', 'Female', 'shruti.p@email.com', '9876543223', 'Flat 9, Ganesh Complex', 'Nashik', 'Maharashtra', '422001'),
('Deepak', 'Mishra', '2003-08-16', 'Male', 'deepak.m@email.com', '9876543224', 'Road No 1, ABC Colony', 'Bhubaneswar', 'Odisha', '751001'),
('Ishita', 'Agarwal', '2002-09-08', 'Female', 'ishita.a@email.com', '9876543225', 'Sector 21, Phase III', 'Gurgaon', 'Haryana', '122001'),
('Pranav', 'Rao', '2004-03-01', 'Male', 'pranav.r@email.com', '9876543226', '6, Railway Quarters', 'Visakhapatnam', 'Andhra Pradesh', '530001'),
('Sana', 'Khan', '2003-05-13', 'Female', 'sana.k@email.com', '9876543227', '8, Model Town', 'Bhopal', 'Madhya Pradesh', '462001'),
('Yash', 'Singh', '2001-02-28', 'Male', 'yash.s@email.com', '9876543228', 'Block B-4, DLF Colony', 'Noida', 'Uttar Pradesh', '201301'),
('Ritika', 'Das', '2004-10-10', 'Female', 'ritika.d@email.com', '9876543229', 'Plot 11, Green Valley', 'Guwahati', 'Assam', '781001'),
('Manish', 'Kumar', '2003-01-05', 'Male', 'manish.k@email.com', '9876543230', '4, Old Delhi Rd', 'Delhi', 'Delhi', '110002'),
('Pooja', 'Verma', '2002-07-17', 'Female', 'pooja.v@email.com', '9876543231', '14, Brigade Rd', 'Bengaluru', 'Karnataka', '560025'),
('Gaurav', 'Sharma', '2004-09-09', 'Male', 'gaurav.sh@email.com', '9876543232', 'C-7, Bandra West', 'Mumbai', 'Maharashtra', '400050'),
('Sakshi', 'Jain', '2003-03-25', 'Female', 'sakshi.j@email.com', '9876543233', '21, Anna Salai', 'Chennai', 'Tamil Nadu', '600002'),
('Kunal', 'Agarwal', '2001-12-01', 'Male', 'kunal.a@email.com', '9876543234', 'A-1, Vastrapur', 'Ahmedabad', 'Gujarat', '380015'),
('Meera', 'Deshmukh', '2004-06-11', 'Female', 'meera.d@email.com', '9876543235', 'Sector 10, Kothrud', 'Pune', 'Maharashtra', '411038'),
('Aditya', 'Singh', '2002-04-04', 'Male', 'aditya.s@email.com', '9876543236', '30, Jubilee Hills', 'Hyderabad', 'Telangana', '500033'),
('Shreya', 'Mittal', '2003-10-19', 'Female', 'shreya.m@email.com', '9876543237', '19, Civil Lines', 'Jaipur', 'Rajasthan', '302006'),
('Vikas', 'Gupta', '2001-05-08', 'Male', 'vikas.g@email.com', '9876543238', 'Block D, Salt Lake', 'Kolkata', 'West Bengal', '700064'),
('Sanjana', 'Sharma', '2004-02-07', 'Female', 'sanjana.sh@email.com', '9876543239', '12, Mall Road', 'Dehradun', 'Uttarakhand', '248001');


-- 2. Insert 5-7 Records into Courses Table
INSERT INTO Courses (CourseName, CourseCode, Credits, Department) VALUES
('Database Management Systems', 'CS301', 4, 'Computer Science'),
('Object-Oriented Programming', 'CS201', 3, 'Computer Science'),
('Calculus I', 'MA101', 4, 'Mathematics'),
('Linear Algebra', 'MA201', 3, 'Mathematics'),
('Digital Electronics', 'EE205', 4, 'Electrical Engineering'),
('Indian History 1857-1947', 'HS102', 3, 'History'),
('Environmental Studies', 'EV101', 2, 'Environmental Science');


-- 3. Insert Records into Marks Table
-- Aim for roughly 2-3 courses per student, creating about 60-90 mark entries
-- (Just showing a subset to keep the example concise, but imagine more combinations)

-- Student 1 (Rohan Sharma)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(1, 1, 88.50, 'A', '2024-05-10'), -- CS301
(1, 2, 75.00, 'B', '2024-05-15'), -- CS201
(1, 3, 91.25, 'A+', '2024-05-20'); -- MA101

-- Student 2 (Priya Singh)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(2, 1, 92.00, 'A+', '2024-05-10'),
(2, 4, 80.00, 'B+', '2024-05-25'); -- MA201

-- Student 3 (Amit Kumar)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(3, 2, 65.50, 'C', '2024-05-15'),
(3, 5, 70.00, 'B-', '2024-05-28'); -- EE205

-- Student 4 (Sneha Gupta)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(4, 3, 89.00, 'A', '2024-05-20'),
(4, 6, 78.75, 'B+', '2024-05-30'); -- HS102

-- Student 5 (Vivek Patel)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(5, 1, 72.00, 'B', '2024-05-10');

-- Student 6 (Anjali Dubey)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(6, 2, 81.00, 'B+', '2024-05-15');

-- Student 7 (Sachin Yadav)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(7, 3, 77.00, 'B', '2024-05-20');

-- Student 8 (Divya Reddy)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(8, 4, 95.00, 'A+', '2024-05-25');

-- Student 9 (Rahul Mehta)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(9, 5, 68.00, 'C+', '2024-05-28');

-- Student 10 (Neha Sharma)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(10, 6, 82.50, 'A-', '2024-05-30');

-- Student 11 (Arjun Verma)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(11, 1, 70.00, 'B-', '2024-05-10'),
(11, 3, 75.00, 'B', '2024-05-20');

-- Student 12 (Kavya Nair)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(12, 2, 88.00, 'A', '2024-05-15'),
(12, 4, 90.00, 'A+', '2024-05-25');

-- Student 13 (Gaurav Jain)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(13, 5, 55.00, 'F', '2024-05-28'),
(13, 1, 60.00, 'C-', '2024-05-10');

-- Student 14 (Shruti Pawar)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(14, 6, 92.00, 'A+', '2024-05-30'),
(14, 2, 85.00, 'A', '2024-05-15');

-- Student 15 (Deepak Mishra)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(15, 1, 78.00, 'B+', '2024-05-10'),
(15, 5, 72.00, 'B', '2024-05-28');

-- Student 16 (Ishita Agarwal)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(16, 2, 89.00, 'A', '2024-05-15'),
(16, 6, 80.00, 'B+', '2024-05-30');

-- Student 17 (Pranav Rao)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(17, 3, 65.00, 'C', '2024-05-20'),
(17, 4, 70.00, 'B-', '2024-05-25');

-- Student 18 (Sana Khan)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(18, 1, 90.00, 'A+', '2024-05-10');

-- Student 19 (Yash Singh)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(19, 2, 77.00, 'B', '2024-05-15');

-- Student 20 (Ritika Das)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(20, 3, 85.00, 'A', '2024-05-20');

-- Student 21 (Manish Kumar)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(21, 4, 70.00, 'B-', '2024-05-25');

-- Student 22 (Pooja Verma)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(22, 5, 88.00, 'A', '2024-05-28');

-- Student 23 (Gaurav Sharma)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(23, 6, 75.00, 'B', '2024-05-30');

-- Student 24 (Sakshi Jain)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(24, 1, 91.00, 'A+', '2024-05-10');

-- Student 25 (Kunal Agarwal)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(25, 2, 82.00, 'A-', '2024-05-15');

-- Student 26 (Meera Deshmukh)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(26, 3, 79.00, 'B+', '2024-05-20');

-- Student 27 (Aditya Singh)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(27, 4, 60.00, 'C-', '2024-05-25');

-- Student 28 (Shreya Mittal)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(28, 5, 93.00, 'A+', '2024-05-28');

-- Student 29 (Vikas Gupta)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(29, 6, 81.00, 'B+', '2024-05-30');

-- Student 30 (Sanjana Sharma)
INSERT INTO Marks (StudentID, CourseID, MarksObtained, Grade, ExamDate) VALUES
(30, 1, 76.00, 'B', '2024-05-10');
use companydb;
SELECT
    FirstName,
    LastName,
    DateOfBirth
FROM Employee
WHERE DateOfBirth > '2002-01-01';

USE university_management_db;
SELECT
    MarkID,
    StudentID,
    CourseID,
    MarksObtained,
    Grade
FROM Marks
WHERE MarksObtained >= 80;

SELECT
    CourseID,
    CourseName,
    Credits
FROM Courses
WHERE Credits = 4;

SELECT
    MarkID,
    MarksObtained,
    MarksObtained + 5 AS IncreasedMarks
FROM Marks;

SELECT
    StudentID,
    FirstName,
    LastName
FROM Students
WHERE StudentID < 10;

SELECT
    MarkID,
    StudentID,
    CourseID,
    MarksObtained,
    Grade
FROM Marks
WHERE MarksObtained < 40;

SELECT
    CourseID,
    CourseName,
    Credits
FROM Courses
WHERE Credits <> 3;

SELECT
    MarkID,
    StudentID,
    CourseID,
    MarksObtained,
    Grade
FROM Marks
WHERE Grade = 'A+';

SELECT
    StudentID,
    FirstName,
    LastName,
    Gender,
    City
FROM Students
WHERE Gender = 'Female'
AND City = 'Delhi';

SELECT
    StudentID,
    FirstName,
    LastName,
    State
FROM Students
WHERE State = 'Maharashtra'
OR State = 'Gujarat';

SELECT
    CourseID,
    CourseName,
    Department,
    Credits
FROM Courses
WHERE Department = 'Computer Science'
AND Credits > 3;

SELECT
    MarkID,
    StudentID,
    CourseID,
    MarksObtained,
    Grade
FROM Marks
WHERE MarksObtained > 70
AND Grade = 'B';

SELECT
    StudentID,
    FirstName,
    LastName,
    City
FROM Students
WHERE NOT City = 'Delhi';

SELECT
    MarkID,
    StudentID,
    CourseID,
    MarksObtained,
    Grade
FROM Marks
WHERE CourseID = 1
OR Grade = 'A';

SELECT
    StudentID,
    FirstName,
    LastName
FROM Students
WHERE LastName LIKE 'S%';

SELECT
    MarkID,
    StudentID,
    CourseID,
    MarksObtained,
    Grade
FROM Marks
WHERE MarksObtained BETWEEN 75 AND 90;

SELECT
    StudentID,
    FirstName,
    LastName,
    City
FROM Students
WHERE City IN ('Chennai', 'Mumbai', 'Bengaluru');

SELECT
    StudentID,
    FirstName,
    LastName,
    Email
FROM Students
WHERE Email LIKE '%@email.com';

SELECT
    StudentID,
    FirstName,
    LastName,
    DateofBirth
FROM Students
WHERE DateOfBirth BETWEEN '2002-01-01' AND '2003-12-31';

SELECT
    MarkID,
    StudentID,
    CourseID,
    MarksObtained,
    Grade
FROM Marks
WHERE Grade = 'A+';

SELECT
    CourseID,
    CourseName,
    CourseCode,
    Credits
FROM Courses
WHERE CourseCode LIKE 'CS%';

SELECT
    StudentID,
    FirstName,
    LastName,
    PhoneNumber
FROM Students
WHERE PhoneNumber LIKE '%10';

SELECT
    MarkID,
    StudentID,
    CourseID,
    MarksObtained,
    Grade
FROM Marks
WHERE StudentID IN (1, 5, 10, 15);