CREATE DATABASE BATCH6_DB;

USE BATCH6_DB;

CREATE TABLE Student
( roll_no INT,
name VARCHAR(200),
Percentage DECIMAL(5,2)
);

insert into Student (roll_no,name,percentage)
                 VALUES(1,'Amit Dube',78.95);    

insert into Student (roll_no,name,percentage)
                 VALUES
                       (2,'Kishor M',80.60),
					   (3,'Vaishali karandikar',92.45),
                        (4,'Uday more',55.78);

SELECT * FROM Student;

SELECT PERCENTAGE, NAME FROM STUDENT;


















































