-- 1. Create the database
CREATE DATABASE analytics_lab;
USE analytics_lab;

-- 2. Create the table
CREATE TABLE customer_feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100),
    email_address VARCHAR(100),
    raw_comment TEXT,
    product_code VARCHAR(20) -- Format: CATEGORY-ID-YEAR
);

INSERT INTO customer_feedback (full_name, email_address, raw_comment, product_code) VALUES
('  alice johnson  ', 'ALICE.J@example.com', 'Great product, loved it!', 'ELEC-101-2026'),
('bob smith', 'bob.smith@company.org', '   Quality could be better.  ', 'HOME-202-2026'),
('CHARLIE BROWN', 'charlie.b@web.net', 'Fast shipping!', 'ELEC-103-2026'),
('diana prince', 'diana@hero.com', 'Product arrived damaged.', 'TOYS-505-2026'),
('  Edward Norton ', 'edward.n@film.com', 'Absolutely fantastic service!', 'HOME-404-2026'),
('FIONA GALLAGHER', 'fiona@south.side', 'It is okay, nothing special.', 'ELEC-101-2026'),
('george miller', 'GEORGE@MAD.COM', 'The manual was missing.', 'BOOK-909-2026'),
('hannah abbott', 'hannah.a@hogwarts.edu', '  Highly recommend to everyone! ', 'HOME-202-2026'),
('IAN WRIGHT', 'ian@football.com', 'Too expensive for what it is.', 'ELEC-103-2026'),
('julia roberts', 'J.ROBERTS@HOLLYWOOD.COM', 'Love the color options.', 'TOYS-505-2026'),
('  kevin hart  ', 'kevin@comedy.com', 'Funny design, bad quality.', 'HOME-404-2026'),
('laura palmer', 'laura@twinpeaks.com', 'It stopped working after a week.', 'ELEC-101-2026'),
('MIKE TYSON', 'mike@boxing.com', 'Powerful performance!', 'ELEC-103-2026'),
('nina simone', 'nina@jazz.com', 'Beautifully crafted.', 'HOME-202-2026'),
('oscar wilde', 'oscar@writer.com', 'A work of art.', 'BOOK-909-2026'),
('  peter parker ', 'peter@spider.com', 'Amazing value.', 'TOYS-505-2026'),
('QUINN FABRAY', 'quinn@glee.com', 'Not what I expected.', 'ELEC-101-2026'),
('rachel green', 'rachel@fashion.com', 'Fits perfectly!', 'HOME-404-2026'),
('steve rogers', 'STEVE@CAP.COM', 'Durable and reliable.', 'ELEC-103-2026'),
('tony stark', 'tony@stark.com', 'Needs more features.', 'ELEC-101-2026'),
('  uma thurman  ', 'uma@killbill.com', 'Fast delivery.', 'TOYS-505-2026'),
('victor vance', 'victor@vice.com', 'Average product.', 'HOME-202-2026'),
('WANDA MAXIMOFF', 'wanda@magic.com', 'Changed my life!', 'BOOK-909-2026'),
('xena warrior', 'xena@princess.com', 'Strong build quality.', 'ELEC-103-2026'),
('yara greyjoy', 'yara@iron.com', 'Not water resistant.', 'HOME-404-2026'),
('zack snyder', 'zack@dceu.com', 'Great visuals on the product.', 'TOYS-505-2026'),
('  amy pond  ', 'amy@tardis.com', 'Fantastic!', 'ELEC-101-2026'),
('bruce wayne', 'BRUCE@GOTHAM.COM', 'Expensive, but worth it.', 'HOME-404-2026'),
('clark kent', 'clark@dailyplanet.com', 'Could be faster.', 'ELEC-103-2026'),
('donna noble', 'donna@doctor.com', 'Very happy with purchase.', 'HOME-202-2026'),
('elias vance', 'elias@science.com', 'Interesting concept.', 'BOOK-909-2026'),
('  faith lehane  ', 'faith@slayer.com', 'Slightly broken.', 'TOYS-505-2026'),
('gordon ramsay', 'gordon@kitchen.com', 'Finally a good product!', 'ELEC-101-2026'),
('harry potter', 'HARRY@HOGWARTS.EDU', 'Magic!', 'BOOK-909-2026'),
('iris west', 'iris@flash.com', 'Arrived too late.', 'ELEC-103-2026'),
('jack sparrow', 'jack@pirate.com', 'Where is the rum?', 'HOME-202-2026'),
('  karen page  ', 'karen@journal.com', 'Good reporting.', 'HOME-404-2026'),
('logan howlett', 'logan@xmen.com', 'Too sharp.', 'TOYS-505-2026'),
('matt murdock', 'MATT@DEVIL.COM', 'I cannot see the quality.', 'ELEC-101-2026'),
('natasha romanoff', 'natasha@spy.com', 'Hidden gems.', 'BOOK-909-2026'),
('olivia pope', 'olivia@fixer.com', 'Fixed my problems.', 'ELEC-103-2026'),
('  paul atreides  ', 'paul@dune.com', 'The spice must flow.', 'HOME-202-2026'),
('quentin lance', 'quentin@star.com', 'Police approved.', 'HOME-404-2026'),
('rose tyler', 'ROSE@BADWOLF.COM', 'Love it!', 'TOYS-505-2026'),
('scott summers', 'scott@xmen.com', 'Laser precision.', 'ELEC-101-2026'),
('troy barnes', 'troy@greendale.com', 'Cool, cool, cool.', 'BOOK-909-2026'),
('  ursula buffay  ', 'ursula@twin.com', 'Whatever.', 'ELEC-103-2026'),
('vito corleone', 'vito@godfather.com', 'An offer I cannot refuse.', 'HOME-404-2026'),
('wade wilson', 'WADE@POOL.COM', 'So funny.', 'TOYS-505-2026'),
('yoda master', 'yoda@force.com', 'Great, it is.', 'BOOK-909-2026');

select * from customer_feedback;



