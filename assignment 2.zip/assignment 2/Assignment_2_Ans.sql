
    USE university_management_db;

   -- Today's Session

  --   1. Aggregate Functions
  
    --  a) COUNT()
           --  counts the number of rows

        -- total number of students

        SELECT COUNT(*) AS TotalStudents
        FROM Students;

       -- Number of distinct cities students are from
       
        SELECT COUNT(DISTINCT city) AS NumberofCities
        FROM Students;  

    --   b) SUM()
   
          -- Total credits for all courses offers

       SELECT SUM(credits) AS TotalCredits
       FROM courses;

 
     -- c) AVG 
            -- average marks obtained across all entries

        SELECT AVG(MarksObtained) AS AverageMark
        FROM marks;

     --  d)   MIN()  , MAX()

           -- lowest marks +  -- Highest marks

          SELECT MIN(MarksObtained) As LowestMark,MAX(MarksObtained) AS HighestMark
          FROM marks;
           
          --  Earliest and latest enrollment dates

         SELECT MIN(enrollmentdate) As "Earliest Ennrolled", 
         MAX(enrollmentdate) AS LatestEnrollment
         FROM students; 
   
  
   --  2. Grouping data with           GROUP BY

    
      --  Purpose
          --   when you use aggregate function, they usually apply to the
          --   entire column.
  
         --   GROUP BY allows you to divide the rows into groups and then 
         --   apply the aggregate function to each Group

 
     --  Syntax :
       --      Select columns, aggregate_function FROM table GROUP BY column(s)

     --  RULE:
		-- Any column in the SELECT list 
		-- that is not part of Agrregate function
		-- must be included in the GROUP BY clause

      -- Count students per city

        ---- How many students are from each city

       SELECT city,Count(StudentID) AS NumberofStudents
       FROM students
       GROUP BY City;

    -- Get the average marks for each course ( Course id)

      SELECT courseid,AVG(marksobtained) as AVG_COURSE_MARK
      FROM marks
      GROUP BY courseid;

    -- count students by gender within each city

    SELECT city,gender, COUNT(studentid) AS countofstudents
    FROM Students
    GROUP BY city,Gender
    ORDER BY city,Gender; 



    -- 3. Filtering Groups with        HAVING 

      -- Purpose :
		--  WHERE ---- filters individual rows before grouping.
		-- HAVING   filters groups after
                   -- grouping and Aggregation

      
     -- Syntax :
               -- ........ GROUP BY column(s)
                       -- HAVING condition_on_aggregate_function;

          -- find cities with more than 3 students
 
         SELECT city,COUNT(studentid) AS NumberOfStudents
         FROM Students
         GROUP BY city
         HAVING COUNT(studentid) >3;  


      --  courses with average marks above 80

       SELECT courseid,AVG(marksobtained) AS avgmarks
       FROM marks
       GROUP BY Courseid
       HAVING AVG(marksobtained) > 80;
 
-- 4. Aggregate Functions
-- Focus: COUNT, SUM, AVG, MIN, MAX.----- Scaler queries (Single value output)

-- 24.	Students: What is the total number of students enrolled?.
SELECT COUNT(*) AS TotalStudents
FROM Students;

-- 25.	Marks: What are the highest marks obtained across all courses?.
SELECT MAX(MarksObtained) AS HighestMarks
FROM Marks;

-- 26.	Marks: What is the average MarksObtained by all students?.
SELECT AVG(MarksObtained) AS AverageMarks
FROM Marks;

-- 27.	Courses: What is the total sum of Credits offered by the university?.
SELECT SUM(Credits) AS TotalCredits
FROM Courses;

-- 28.	Marks: Find the lowest mark recorded in the Marks table.
SELECT MIN(MarksObtained) AS LowestMark
FROM Marks;

-- 29.	Students: Count how many students are from the state of 'Maharashtra'.
SELECT COUNT(*) AS MaharashtraStudents
FROM Students
WHERE State = 'Maharashtra';

-- 30.	Marks: Count the total number of exams taken on '2024-05-10'.
SELECT COUNT(*) AS TotalExams
FROM Marks
WHERE ExamDate = '2024-05-10';

-- 31.	Students: Find the date of birth of the oldest student.
SELECT MIN(DateOfBirth) AS OldestStudentDOB
FROM Students;

-- 5. GROUP BY Clause
-- Focus: Categorizing data into groups for summary.

-- 32.	Students: Count the number of students in each City.
SELECT
    City,
    COUNT(StudentID) AS NumberOfStudents
FROM Students
GROUP BY City;

-- 33.	Marks: Find the average marks for each CourseID.
SELECT
    CourseID,
    AVG(MarksObtained) AS AverageMarks
FROM Marks
GROUP BY CourseID;

-- 34.	Students: Group students by Gender and find the total count for each.
SELECT
    Gender,
    COUNT(StudentID) AS TotalStudents
FROM Students
GROUP BY Gender;

-- 35.	Courses: Count how many courses are offered by each Department.
SELECT
    Department,
    COUNT(CourseID) AS TotalCourses
FROM Courses
GROUP BY Department;

-- 36.	Marks: Find the highest mark obtained for each Grade (e.g., max mark for 'A', 'B', etc.).
SELECT
    Grade,
    MAX(MarksObtained) AS HighestMark
FROM Marks
GROUP BY Grade;

-- 37.	Students: Count the number of students from each State.
SELECT
    State,
    COUNT(StudentID) AS TotalStudents
FROM Students
GROUP BY State;

-- 38.	Marks: Count how many students appeared for each ExamDate.
SELECT
    ExamDate,
    COUNT(StudentID) AS TotalStudents
FROM Marks
GROUP BY ExamDate;

-- 39.	Marks: Calculate the total marks obtained by each StudentID.
SELECT
    StudentID,
    SUM(MarksObtained) AS TotalMarks
FROM Marks
GROUP BY StudentID;

-- 40.	Courses: Find the average Credits for each Department.
SELECT
    Department,
    AVG(Credits) AS AverageCredits
FROM Courses
GROUP BY Department;

-- 6. HAVING Clause
-- Focus: Filtering grouped data based on aggregate conditions.

-- 41.	Students: List Cities that have more than 2 students.
SELECT
    City,
    COUNT(StudentID) AS TotalStudents
FROM Students
GROUP BY City
HAVING COUNT(StudentID) > 2;

-- 42.	Marks: Show CourseIDs where the average marks are above 80.
SELECT
    CourseID,
    AVG(MarksObtained) AS AverageMarks
FROM Marks
GROUP BY CourseID
HAVING AVG(MarksObtained) > 80;

-- 43.	Students: List States that have exactly 1 student.
SELECT
    State,
    COUNT(StudentID) AS TotalStudents
FROM Students
GROUP BY State
HAVING COUNT(StudentID) = 1;

-- 44.	Marks: Find StudentIDs who have appeared for more than 2 exams.
SELECT
    StudentID,
    COUNT(*) AS TotalExams
FROM Marks
GROUP BY StudentID
HAVING COUNT(*) > 2;

-- 45.	Courses: Show Departments that offer more than 5 total Credits.
SELECT
    Department,
    SUM(Credits) AS TotalCredits
FROM Courses
GROUP BY Department
HAVING SUM(Credits) > 5;

-- 46.	Marks: List Grades that have been assigned to more than 5 records.
SELECT
    Grade,
    COUNT(*) AS TotalRecords
FROM Marks
GROUP BY Grade
HAVING COUNT(*) > 5;

-- 47.	Students: Find the Year of birth where more than 5 students were born.
SELECT
    YEAR(DateOfBirth) AS BirthYear,
    COUNT(StudentID) AS TotalStudents
FROM Students
GROUP BY YEAR(DateOfBirth)
HAVING COUNT(StudentID) > 5;

-- 48.	Marks: List CourseIDs that have a minimum mark recorded above 60.
SELECT
    CourseID,
    MIN(MarksObtained) AS MinimumMark
FROM Marks
GROUP BY CourseID
HAVING MIN(MarksObtained) > 60;

-- 49.	Marks: Find StudentIDs whose total sum of marks is greater than 150.
SELECT
    StudentID,
    SUM(MarksObtained) AS TotalMarks
FROM Marks
GROUP BY StudentID
HAVING SUM(MarksObtained) > 150;

-- 50.	Students: Group by Gender and show only the groups with more than 10 students
SELECT
    Gender,
    COUNT(StudentID) AS TotalStudents
FROM Students
GROUP BY Gender
HAVING COUNT(StudentID) > 10;












     
            
  




















  