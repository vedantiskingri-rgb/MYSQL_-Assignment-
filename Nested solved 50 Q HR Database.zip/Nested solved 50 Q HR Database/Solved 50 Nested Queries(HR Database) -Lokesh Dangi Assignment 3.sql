-- Questions Not Solved=> 48,51,54,55

create database hr;
USE hr;
/* 1. Write a query to display the name (first name and last name) for 
those employees who gets more salary than the employee whose ID is 163. */
select*from employees where employee_id = 163;
                 --    or
select salary from employees where employee_id = 163;    
 
select FIRST_NAME , LAST_NAME from employees
where salary > (select salary from employees where employee_id=163);

/* 2. Write a query to display the name (first name and last name), 
salary, department id, job id for 
those employees who works in the same designation as the employee works whose id is 169. */
select job_id from employees where employee_id = 169;  
   
select FIRST_NAME , LAST_NAME, salary, department_id,job_id from employees
where job_id = (select job_id from employees where employee_id=169);

/* 3. Write a query to display the name (first name and last name), salary, department id 
for those employees who earn such amount of salary which is the smallest salary of any of the departments. */
SELECT MIN(salary)FROM employees GROUP BY department_id; 
-- or
  SELECT department_id,MIN(salary) AS minimum_salary FROM employees GROUP BY department_id;
  
select FIRST_NAME , LAST_NAME, salary, department_id,job_id from employees
where job_id = (select job_id from employees where employee_id=169);

/* 4. Write a query to display the employee id, employee name (first name and last name) 
for all employees who earn more than the average salary. */
select avg (salary) from employees;

SELECT employee_id,first_name,last_name FROM employees
WHERE salary >(SELECT AVG(salary)FROM employees);
                     -- or
SELECT concat(first_name,'',last_name) AS full_name, salary FROM employees
WHERE salary > (SELECT AVG(salary) FROM employees);   
                  
/* 5. Write a query to display the employee name (first name and last name), 
  employee id and salary of all employees who report to Payam. */
    SELECT employee_id FROM employees WHERE first_name = 'Payam';
   
   SELECT employee_id,
       CONCAT(first_name,' ',last_name) AS full_name,salary FROM employees
WHERE manager_id =
(SELECT employee_id FROM employees WHERE first_name = 'Payam');

/* 6. Write a query to display the department number, name (first name and last name), job_id 
and department name for all employees in the Finance department. */
SELECT department_id FROM departments WHERE department_name = 'Finance';
    
SELECT e.department_id,e.first_name,e.last_name,e.job_id,d.department_name FROM employees e
JOIN departments d ON e.department_id = d.department_id
WHERE d.department_name = 'Finance';

/* 7. Write a query to display all the information of an employee whose salary 
and reporting person id is 3000 and 121, respectively. */
   SELECT * FROM employees WHERE salary = 3000 AND manager_id = 121;
   
/* 8. Display all the information of an employee 
whose id is any of the number 134, 159 and 183. */
 
 SELECT * FROM employees WHERE employee_id IN (134,159,183);

/* 9. Write a query to display all the information of the 
employees whose salary is within the range 1000 and 3000. */
 
SELECT * FROM employees WHERE salary BETWEEN 1000 AND 3000;

/* 10. Write a query to display all the information of the employees 
whose salary is within the range of smallest salary and 2500. */
  SELECT MIN(salary) FROM employees;

SELECT * FROM employees WHERE salary BETWEEN
(SELECT MIN(salary) FROM employees)AND 2500;

/* 11. Write a query to display all the information of the employees 
who does not work in those departments where some employees works whose manager id 
within the range 100 and 200. */

SELECT department_id FROM employees WHERE manager_id BETWEEN 100 AND 200;

SELECT * FROM employees
WHERE department_id NOT IN
(SELECT department_id FROM employees
WHERE manager_id BETWEEN 100 AND 200);

/* 12. Write a query to display all the information for those 
employees whose id is any id who earn the second highest salary. */
      
  SELECT MAX(salary) FROM employees WHERE salary < (SELECT MAX(salary) FROM employees);    

SELECT * FROM employees WHERE salary =
(SELECT MAX(salary)FROM employees WHERE salary <(SELECT MAX(salary)FROM employees));

/* 13. Write a query to display the employee name (first name and last name) 
and hire date for all employees in the same department as Clara. Exclude Clara. */

   SELECT department_idFROM employees WHERE first_name = 'Clara';
  
  SELECT CONCAT(first_name,' ',last_name) AS full_name,hire_date
FROM employees
WHERE department_id =
(
    SELECT department_id
    FROM employees
    WHERE first_name = 'Clara'
)
AND first_name <> 'Clara';
  
--  String pattern  & location    LIKE  %  _
/* 14. Write a query to display the employee number and name (first name and last name)
 for all employees who work in a department with 
 any employee whose name contains a T. */

SELECT department_id FROM employees WHERE first_name LIKE '%T%'OR last_name LIKE '%T%';

SELECT employee_id,
       CONCAT(first_name,' ',last_name) AS full_name FROM employees
WHERE department_id IN(
    SELECT department_id FROM employees WHERE first_name LIKE '%T%'OR last_name LIKE '%T%');
    
/* 15. Write a query to display the employee number, name (first name and last name), 
and salary for all employees who earn more than the average salary and 
who work in a department with any employee with a J in their name. */
    
    SELECT AVG(salary) FROM employees;

SELECT department_id FROM employees WHERE first_name LIKE '%J%'OR last_name LIKE '%J%';
    -- or 
SELECT employee_id,
       CONCAT(first_name,' ',last_name) AS full_name,salary
FROM employees WHERE salary >(SELECT AVG(salary)FROM employees)
AND department_id IN
(SELECT department_id FROM employees WHERE first_name LIKE '%J%'OR last_name LIKE '%J%');    

/* 16. Display the employee name (first name and last name), employee id, and job 
title for all employees whose department location is Toronto. */

SELECT location_id FROM locations WHERE city = 'Toronto';

SELECT employee_id,
       CONCAT(first_name,' ',last_name) AS full_name,
       job_title
FROM employees e
JOIN departments d
ON e.department_id = d.department_id
JOIN locations l
ON d.location_id = l.location_id
JOIN jobs j
ON e.job_id = j.job_id
WHERE l.city = 'Toronto';

--    Multi rows category // comparision with multiple rows

/* 17. Write a query to display the employee number, name (first name and last name) 
and job title for all employees whose salary is smaller than any salary of those employees whose job title is MK_MAN. */

SELECT salary FROM employees WHERE job_id = 'MK_MAN';

SELECT employee_id,CONCAT(first_name,' ',last_name) AS full_name,job_id
FROM employees
WHERE salary < ANY(
    SELECT salary
    FROM employees
    WHERE job_id = 'MK_MAN');

/* 18. Write a query to display the employee number, name (first name and last name) 
and job title for all employees whose salary is smaller than any salary of 
those employees whose job title is MK_MAN. Exclude Job title MK_MAN. */

SELECT employee_id,CONCAT(first_name,' ',last_name) AS full_name,job_id
FROM employees
WHERE salary < ANY(
SELECT salary
FROM employees
WHERE job_id = 'MK_MAN');

/* 19. Write a query to display the employee number, name (first name and last name)
 and job title for all employees whose salary is more than any salary of those 
employees whose job title is PU_MAN. Exclude job title PU_MAN. */

SELECT employee_id,CONCAT(first_name,' ',last_name) AS full_name,job_id
FROM employees
WHERE salary > ANY(
    SELECT salary
    FROM employees
    WHERE job_id = 'PU_MAN')
AND job_id <> 'PU_MAN';


/* 20. Write a query to display the employee number, name (first name and last name) 
and job title for all employees whose salary is more than any average salary of any department. */

SELECT AVG(salary)FROM employees GROUP BY department_id;

SELECT employee_id,CONCAT(first_name,' ',last_name) AS full_name,job_id
FROM employees
WHERE salary > ANY(
    SELECT AVG(salary)
    FROM employees
    GROUP BY department_id);


/* 21. Write a query to display the employee name( first name and last name ) 
and department for all employees for any existence of those employees whose salary is more than 3700. */

SELECT salary FROM employees WHERE salary > 3700;

SELECT CONCAT(e.first_name,' ',e.last_name) AS full_name,d.department_name
FROM employees e
JOIN departments d
ON e.department_id = d.department_id
WHERE EXISTS
(
    SELECT *
    FROM employees
    WHERE salary > 3700
);

/* 22. Write a query to display the department id and the total salary 
for those departments which contains at least one employee. */

SELECT department_id,SUM(salary) AS total_salary
FROM employees
GROUP BY department_id
HAVING COUNT(employee_id) >= 1;

/* 23. Write a query to display the employee id, name (first name and last name) 
and the job id column with a modified title SALESMAN for those employees whose 
job title is ST_MAN and DEVELOPER for whose job title is IT_PROG. */


SELECT employee_id,CONCAT(first_name,' ',last_name) AS full_name,
       CASE
           WHEN job_id='ST_MAN' THEN 'SALESMAN'
           WHEN job_id='IT_PROG' THEN 'DEVELOPER'
           ELSE job_id
       END AS job_title
FROM employees;

/* 24. Write a query to display the employee id, name (first name and last name), salary 
and the SalaryStatus column with a title HIGH and LOW respectively for 
those employees whose salary is more than and less than the average salary of all employees. */

SELECT AVG(salary)FROM employees;

SELECT employee_id,CONCAT(first_name,' ',last_name) AS full_name,salary,
       CASE
		WHEN salary >(SELECT AVG(salary) FROM employees)THEN 'HIGH'ELSE 'LOW'
       END AS SalaryStatus
FROM employees;


/* 25. Write a query to display the employee id, name (first name and last name), 
Salary, AvgCompare (salary - the average salary of all employees) and the SalaryStatus column with 
a title HIGH and LOW respectively for those employees whose salary is more than and less than the average salary of all employees. */

SELECT AVG(salary)FROM employees;

SELECT employee_id,
       CONCAT(first_name,' ',last_name) AS full_name,
       salary,
       salary -
       (SELECT AVG(salary)
        FROM employees) AS AvgCompare,
       CASE
		WHEN salary >(SELECT AVG(salary)FROM employees)
		THEN 'HIGH'ELSE 'LOW'END AS SalaryStatus
FROM employees;

/* 26. Write a subquery that returns a set of rows to find all departments 
that do actually have one or more employees assigned to them. */

SELECT DISTINCT department_id FROM employees;

SELECT * FROM departments
WHERE department_id IN
(SELECT department_id FROM employees);

/* 27. Write a query that will identify all employees who work 
in departments located in the United Kingdom. */

SELECT * FROM departments WHERE department_id IN
(SELECT department_id FROM employees);

SELECT employee_id,CONCAT(first_name,' ',last_name) AS full_name
FROM employees
WHERE department_id IN
(
    SELECT department_id
    FROM departments
    WHERE location_id IN
    (
        SELECT location_id
        FROM locations
        WHERE country_id=
        (
            SELECT country_id
            FROM countries
            WHERE country_name='United Kingdom'
            )));



/* 28. Write a query to identify all the employees 
who earn more than the average and who work in any of the IT departments. */

SELECT AVG(salary)FROM employees;

SELECT department_id FROM departments WHERE department_name LIKE '%IT%';

SELECT employee_id,CONCAT(first_name,' ',last_name) AS full_name,salary
FROM employees
WHERE salary >
(
    SELECT AVG(salary)
    FROM employees
)
AND department_id IN
(
    SELECT department_id
    FROM departments
    WHERE department_name LIKE '%IT%'
);

/* 29. Write a query to determine who earns more than Mr. Ozer. */
SELECT salary FROM employees WHERE last_name='Ozer';

SELECT employee_id,CONCAT(first_name,' ',last_name) AS full_name,salary
FROM employees
WHERE salary >
(
    SELECT salary
    FROM employees
    WHERE last_name='Ozer'
);

/* 30. Write a query to find out which employees have a manager who works for a department based in the US. */

SELECT employee_id FROM employees WHERE department_id IN
(SELECT department_id FROM departments WHERE location_id IN
    (SELECT location_id FROM locations WHERE country_id='US'));

SELECT employee_id,CONCAT(first_name,' ',last_name) AS full_name,manager_id
FROM employees
WHERE manager_id IN
(
    SELECT employee_id
    FROM employees
    WHERE department_id IN
    (
        SELECT department_id
        FROM departments
        WHERE location_id IN
        (
            SELECT location_id
            FROM locations
            WHERE country_id='US'
        )));

/* 31. Write a query which is looking for the names of all employees whose salary 
is greater than 50% of their department’s total salary bill. */

SELECT department_id,SUM(salary) AS total_salary
FROM employees GROUP BY department_id;

SELECT CONCAT(first_name,' ',last_name) AS full_name,salary,department_id
FROM employees e
WHERE salary >
(
    SELECT SUM(salary) * 0.5
    FROM employees
    WHERE department_id = e.department_id
);

/* 32. Write a query to get the details of employees who are managers. */

SELECT DISTINCT manager_id FROM employees
WHERE manager_id IS NOT NULL;

SELECT * FROM employees
WHERE employee_id IN
(
    SELECT DISTINCT manager_id
    FROM employees
    WHERE manager_id IS NOT NULL
);

/* 33. Write a query to get the details of employees who manage a department. */

SELECT manager_id FROM departments
WHERE manager_id IS NOT NULL;

SELECT * FROM employees
WHERE employee_id IN
(
    SELECT manager_id
    FROM departments
    WHERE manager_id IS NOT NULL
);

/* 34. Write a query to display the employee id, name (first name and last name), 
salary, department name and city for all the employees who gets the salary as the 
salary earn by the employee which is maximum within the 
joining person January 1st, 2002 and December 31st, 2003. */

SELECT MAX(salary)FROM employees
WHERE hire_date BETWEEN '2002-01-01' AND '2003-12-31';

SELECT e.employee_id,CONCAT(e.first_name,' ',e.last_name) AS full_name,e.salary,d.department_name,l.city
FROM employees e
JOIN departments d
ON e.department_id = d.department_id
JOIN locations l
ON d.location_id = l.location_id
WHERE e.salary =(
    SELECT MAX(salary)
    FROM employees
    WHERE hire_date BETWEEN '2002-01-01' AND '2003-12-31');

/* 35. Write a query in SQL to display the department code and name 
for all departments which located in the city London. */

SELECT location_id FROM locations
WHERE city='London';


SELECT department_id,department_name FROM departments
WHERE location_id =
(
    SELECT location_id
    FROM locations
    WHERE city='London'
);

/* 36. Write a query in SQL to display the first and last name, salary, 
and department ID for all those employees who earn more than the 
average salary and arrange the list in descending order on salary. */


SELECT AVG(salary)FROM employees;

SELECT first_name,last_name,salary,department_id FROM employees
WHERE salary >(
    SELECT AVG(salary)
    FROM employees)
ORDER BY salary DESC;

/* 37. Write a query in SQL to display the first and last name,
 salary, and department ID for those employees who earn more than the
 maximum salary of a department which ID is 40. */

SELECT MAX(salary)FROM employees WHERE department_id=40;

SELECT first_name,last_name,salary,department_id FROM employees
WHERE salary >(
    SELECT MAX(salary)
    FROM employees
    WHERE department_id=40
);

/* 38. Write a query in SQL to display the department name and Id for 
all departments where they located, that Id is equal to the Id for the location
 where department number 30 is located. */

SELECT location_id FROM departments
WHERE department_id=30;

SELECT department_id,department_name FROM departments
WHERE location_id =(
    SELECT location_id
    FROM departments
    WHERE department_id=30);

/* 39. Write a query in SQL to display the first and last name, salary, and 
department ID for all those employees who work in that department where the employee works who hold the ID 201. */


SELECT department_id FROM employees
WHERE employee_id=201;

SELECT first_name,last_name,salary,department_id FROM employees
WHERE department_id =
(
    SELECT department_id
    FROM employees
    WHERE employee_id=201
);

/* 40. Write a query in SQL to display the first and last name, salary, 
and department ID for those employees whose salary is equal to the salary of the 
employee who works in that department which ID is 40. */

SELECT salary FROM employees
WHERE department_id=40;

SELECT first_name,last_name,salary,department_id FROM employees
WHERE salary IN(
    SELECT salary
    FROM employees
    WHERE department_id=40);

/* 41. Write a query in SQL to display the first and last name, and department 
code for all employees who work in the department Marketing. */

select department_id from departments where department_name='Marketing'; 

select first_name,last_name,department_id,job_id
from employees 
where department_id = 
(select department_id from departments where department_name='Marketing');

/* 42. Write a query in SQL to display the first and last name, salary, and 
department ID for those employees who earn more than the minimum salary of a department which ID is 40. */

select min(salary) from employees  where department_id=40;

select first_name,last_name,department_id,salary
from employees 
where salary >
(select min(salary) from employees  where department_id=40);


/* 43. Write a query in SQL to display the full name, email, and hire date 
for all those employees who was hired after the employee whose ID is 165. */

select hire_date from employees where employee_id=165;

select concat(first_name,' ',last_name),email,hire_date
from employees 
where hire_date >
(select hire_date from employees where employee_id=165);


/* 44. Write a query in SQL to display the first and last name, salary, and department 
ID for those employees who earn less than the minimum salary of a department which ID is 70. */

select min(salary) from employees  where department_id=70;

select first_name,last_name,department_id,salary
from employees 
where salary <
(select min(salary) from employees  where department_id=70);

/* 45. Write a query in SQL to display the first and last name, salary, and department ID 
for those employees who earn less than the average salary, and also work at the 
department where the employee Laura is working as a first name holder. */

select avg(salary) from employees where first_name='Laura';

select first_name,last_name,department_id,salary
from employees 
where salary<(select avg(salary) from employees)
and department_id IN(select department_id from employees where first_name='Laura');

/* 46. Write a query in SQL to display the first and last name, salary, and
 department ID for those employees whose department is located in the city London. */

select * from locations where city='London';

select e.first_name,e.last_name,d.department_id,e.salary
from departments as d ,employees as e
where e.department_id=d.department_id
and 
d.location_id =
(select location_id from locations where city='London');

/* 47. Write a query in SQL to display the city of the employee whose ID 134 and works there. */

select location_id from employees where employee_id=134;

select l.city
from employees e
join departments d on e.department_id=d.department_id
join locations l on d.location_id= l.location_id
where e.employee_id=134;

/* 48. Write a query in SQL to display the the details of those departments
 which max salary is 7000 or above for those employees who already done one or more jobs. */


/* 49. Write a query in SQL to display the detail information of those departments 
which starting salary is at least 8000. */

select * from departments 
where department_id IN
(select department_id from employees 
group by department_id having min(salary)>=8000);

/* 50. Write a query in SQL to display the full name (first and last name) of 
manager who is supervising 4 or more employees. */

select concat(first_name,' ',last_name) as Full_Name
from employees 
where employee_id IN(select manager_id from employees group by manager_id having count(*)>=4);

/* 51. Write a query in SQL to display the details of the current job 
for those employees who worked as a Sales Representative in the past. */




/* 52. Write a query in SQL to display all the information about 
those employees who earn second lowest salary of all the employees. */

select min(salary) from employees;

select min(salary) as second_highest_salary
from employees 
where 
salary >(select min(salary) from employees);

/* 53. Write a query in SQL to display the details of departments managed by Susan. */

select employee_id from employees where first_name='Susan';

select * from departments 
where manager_id=
(select employee_id from employees where first_name='Susan');

/* 54. Write a query in SQL to display the department ID, full name (first and last name), 
salary for those employees who is highest salary drawer in a department. */



/* 55. Write a query in SQL to display all the information of 
those employees who did not have any job in the past. */

select * from employees 
where employee_id not in( select employee_id from job_history);